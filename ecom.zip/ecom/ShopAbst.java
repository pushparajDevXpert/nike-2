package com.ecom;

public interface ShopAbst {
	void login();

	abstract void passwordchecking();

	void signup();

	void captcha();

	void homepage();
}
